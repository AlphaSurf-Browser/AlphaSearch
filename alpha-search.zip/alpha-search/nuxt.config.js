export default {
    // Other configuration settings
    serverMiddleware: [
      { path: '/api', handler: '~/server/api/crawler.js' }, // API route
    ],
  }
  